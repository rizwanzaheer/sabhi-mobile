patch -t ./node_modules/react-native-material-textfield/src/components/affix/index.js < ./.patch/react-native-material-textfield/affix/index.patch
patch -t ./node_modules/react-native-material-textfield/src/components/helper/index.js < ./.patch/react-native-material-textfield/helper/index.patch
patch -t ./node_modules/react-native-material-textfield/src/components/label/index.js < ./.patch/react-native-material-textfield/label/index.patch
